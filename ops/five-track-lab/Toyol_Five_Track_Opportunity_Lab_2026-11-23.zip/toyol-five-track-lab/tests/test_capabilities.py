import unittest
from datetime import datetime, timezone
from core.hunt import HUNTS,check_plan
from core.hybrid import HybridRouter,CloudNotPermitted
from core.glasses import HUD,wrap_card
from core.gemma_guard import validate_python_patch,PatchRejected,detect_simple_off_by_one
from core.tenstorrent_mask import TensorSpec,validate,mask_row,UnsupportedMask

class HuntTests(unittest.TestCase):
    def test_five_tracks(self):
        self.assertEqual(len({h.slug for h in HUNTS}),5)
        for h in HUNTS:
            self.assertFalse(h.cash_required)
            self.assertFalse(check_plan(h.slug,now=datetime(2026,11,23,tzinfo=timezone.utc))['registration_verified'])
    def test_kaggle_deadline_not_closure(self):
        self.assertFalse(check_plan('gemma',now=datetime(2026,11,23,tzinfo=timezone.utc))['deadline_passed'])
        self.assertTrue(check_plan('gemma',now=datetime(2026,12,3,tzinfo=timezone.utc))['deadline_passed'])

class HybridTests(unittest.TestCase):
    def test_device_first(self):
        x=HybridRouter(lambda p:'OK',lambda p:'FAIL'); self.assertEqual(x.ask('hi').path,'device');self.assertEqual(x.cloud_calls,0)
    def test_no_unapproved_cloud(self):
        x=HybridRouter(lambda p: (_ for _ in ()).throw(RuntimeError('No device')),lambda p:'OK')
        with self.assertRaises(CloudNotPermitted):x.ask('hi')
        with self.assertRaises(CloudNotPermitted):x.ask('hi',allow_cloud=True)
        self.assertEqual(x.cloud_calls,0)
    def test_redacts_before_permitted_cloud(self):
        seen=[]; x=HybridRouter(lambda p: (_ for _ in ()).throw(RuntimeError('No device')),lambda p:(seen.append(p),'OK')[1]);
        z=x.ask('Contact x@test.org for this',allow_cloud=True,free_quota_confirmed=True)
        self.assertEqual(z.path,'cloud');self.assertTrue(z.redacted);self.assertNotIn('x@test.org',seen[0])

class GlassesTests(unittest.TestCase):
    def test_compact(self):
        lines=wrap_card('Laporan 1','Hasil siasatan dibincangkan dengan ringkas untuk dipaparkan pada kaca mata')
        self.assertLessEqual(len(lines),4);self.assertTrue(all(len(line)<=30 for line in lines))
    def test_navigation(self):
        x=HUD([('A','one'),('B','two')]);self.assertEqual(x.swipe('right')['index'],2);self.assertEqual(x.swipe('down')['index'],1)

class GemmaTests(unittest.TestCase):
    def test_syntax(self):
        self.assertEqual(validate_python_patch('src/test.py','x = 2\n')['syntax'],'PASS')
        with self.assertRaises(PatchRejected):validate_python_patch('../outside.py','x=1')
        with self.assertRaises(PatchRejected):validate_python_patch('src/a.py','x=')
    def test_guard(self):self.assertEqual(detect_simple_off_by_one('for i in range(len(xs)+1):\n    print(xs[i])')[0]['line'],1)

class TenstorrentTests(unittest.TestCase):
    def test_reject_causal_row_major(self):
        with self.assertRaises(UnsupportedMask):validate(TensorSpec(4,128,128),TensorSpec(4,128,128,layout='ROW_MAJOR'),is_causal=True,sharded=True)
    def test_shard_orientation(self):
        with self.assertRaises(UnsupportedMask):validate(TensorSpec(4,64,128,shard_shape=(32,128),orientation='ROW_MAJOR'),TensorSpec(4,64,128,shard_shape=(32,128),orientation='COL_MAJOR'),is_causal=False,sharded=True)
    def test_row_wrap_and_batch(self):
        self.assertEqual(mask_row(3,25,1,5),(0,0));self.assertEqual(mask_row(3,25,4,5),(3,0))
    def test_valid(self):self.assertTrue(validate(TensorSpec(2,32,64),TensorSpec(2,32,64),is_causal=False,sharded=True))

if __name__=='__main__':unittest.main()
