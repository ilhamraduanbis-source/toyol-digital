"""Actual headless browser tests with Playwright; independent of paid Kane CLI."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading
from functools import partial
root=Path(__file__).resolve().parents[1]
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(root/'web')))
threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':900},device_scale_factor=1,accept_downloads=True)
    page.set_content((root/'web/index.html').read_text(),wait_until='domcontentloaded')
    page.add_style_tag(content=(root/'web/styles.css').read_text())
    page.add_script_tag(content=(root/'web/app.js').read_text())
    assert page.locator('.item').count()==5
    page.get_by_role('button',name='Smart glasses').click()
    assert page.locator('.item').count()==1
    assert 'Even Realities' in page.locator('#section-title').inner_text()
    page.get_by_role('button',name='All',exact=True).click()
    page.get_by_role('button',name='Next HUD card').click()
    assert '2/5' in page.locator('#hud-progress').inner_text()
    page.locator('#prompt').fill('')
    page.get_by_role('button',name='Run device-first simulation').click()
    assert 'prompt required' in page.locator('#route-result').inner_text()
    page.locator('#prompt').fill('hello')
    page.locator('#cloud').check()
    page.get_by_role('button',name='Run device-first simulation').click()
    assert 'Cloud NOT called' in page.locator('#route-result').inner_text()
    with page.expect_download() as d:page.get_by_role('button',name='Export local status JSON').click()
    out=d.value
    assert out.suggested_filename=='toyol-hunt-status.json'
    save=root/'evidence'/'status.json'; save.parent.mkdir(exist_ok=True);out.save_as(save)
    j=json.loads(save.read_text());assert len(j['tracks'])==5 and all(not x['registration_verified'] for x in j['tracks'])
    page.locator('#cloud').uncheck()
    page.screenshot(path=str(root/'evidence'/'browser-proof.png'),full_page=True)
    browser.close()
server.shutdown()
print('BROWSER_E2E_PASS: 5 tracks, filter, HUD, validation, zero-cloud, JSON export, actual screenshot')
