# Toyol ProofDesk — Five-Track Zero-Spend Capability Lab

This is an actual, **local tested** baseline for five opportunities uncovered Nov 23, 2026. It is NOT a completed contest submission or proof that anyone signed up.

## What works now

- KaneCLI track: responsive offline browser dashboard, filtering, realistic HUD, exportable JSON, actual Playwright UI tests and screenshot.
- Even Realities: pure-Python concise HUD compositor and a real Even Hub SDK source integration scaffold based on the sponsor's minimal template.
- Firebase: a local device-first/privacy-aware fallback router with tests and a separate real Firebase AI Logic SDK Web integration (cloud disabled by default).
- Gemma 4: conservative patch validation, syntax checks, and off-by-one warning fixture, **not** a model-powered coding agent.
- Tenstorrent: pure-Python sharded softmax mask checks, tests, and existing competing PR warning, **not** hardware verification or a bounty claim.

## Reproduce tests

```bash
python run_checks.py
python tests/browser_e2e.py       # requires python playwright + Chromium
node --check web/app.js
```

To view the dashboard, open `web/index.html` locally in a compatible browser or serve `web/` over HTTP. Local builds have no API dependencies. For Even G2 and Firebase separate real SDK integrations, see `integrations/COMPETITION_GATES.md`.

## Truthful accounting

- Joined/registered: **not confirmed** in any of the five competitions.
- Submitted: **not confirmed**.
- Paid/awarded: **USD0 confirmed**.
- Internal local checks: 13 Python unit tests, browser E2E interaction, separate SDK integration **not runtime-tested**.
- Spend: RM0 in this lab; no outside paid services called.

## Paths to actual submissions

Read `integrations/COMPETITION_GATES.md`. Registration and signed terms require the user's actual eligible accounts. Never interpret a GitHub commit as official contest enrollment.
