"""Run local zero-dependency capability tests; exits nonzero on regression."""
import unittest
from pathlib import Path
root=Path(__file__).parent
suite=unittest.defaultTestLoader.discover(str(root/'tests'),top_level_dir=str(root))
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
