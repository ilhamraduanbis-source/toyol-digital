"""Pure-Python sharded softmax-mask validator. No device tests or upstream patch implied."""
from dataclasses import dataclass

class UnsupportedMask(ValueError):pass

@dataclass(frozen=True)
class TensorSpec:
    batch:int
    height:int
    width:int
    layout:str='TILE'
    shard_shape:tuple[int,int]|None=None
    orientation:str|None=None


def validate(input:TensorSpec, mask:TensorSpec, *, is_causal:bool, sharded:bool) -> bool:
    for t in (input,mask):
        if min(t.batch,t.height,t.width)<=0:raise UnsupportedMask('Nonpositive shape')
        if t.layout not in {'TILE','ROW_MAJOR'}:raise UnsupportedMask('Unknown layout')
    if is_causal and mask.layout=='ROW_MAJOR':
        raise UnsupportedMask('Causal row-major mask unsupported in sharded path')
    if mask.batch not in (input.batch,1):
        raise UnsupportedMask('Mask batch must match input or be explicitly broadcastable')
    if sharded:
        if mask.shard_shape is not None and input.shard_shape!=mask.shard_shape:
            raise UnsupportedMask('Incompatible shard shape')
        if mask.shard_shape is not None and mask.orientation!=input.orientation:
            raise UnsupportedMask('Incompatible shard orientation')
        if mask.height < 1:raise UnsupportedMask('Invalid mask height')
    return True

def mask_row(input_batch:int, row:int, mask_batch:int, mask_height:int)->tuple[int,int]:
    """Wrap by mask height, not input width. Broadcast batch one across input batches."""
    if input_batch<0 or row<0 or mask_batch<1 or mask_height<1:
        raise UnsupportedMask('Invalid index')
    return (0 if mask_batch==1 else input_batch%mask_batch, row%mask_height)
