"""Verified opportunity boundaries and no-spend safeguards. No registration claims."""
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

@dataclass(frozen=True)
class Hunt:
    slug: str
    name: str
    deadline_utc: Optional[str]
    register_url: str
    track: str
    cash_required: bool
    requires_external_account: bool
    restrictions: str

HUNTS = (
    Hunt('kane','KaneCLI Online Hackathon','2026-11-26T18:29:00Z','https://www.kaneclihack.sh/o/register','browser_qa',False,True,'Proof of genuine Kane CLI tests required'),
    Hunt('even','Heads Up Even Realities','2026-11-29T19:59:00Z','https://www.eventbrite.com/e/heads-up-even-realities-hackathon-by-tvm-ventures-daos-hub-tickets-2004953173915','glasses_ui',False,True,'Use real Even Hub SDK and simulator; public repo and video'),
    Hunt('firebase','Firebase #BuildHybridAI 2026','2026-11-30T22:00:00Z','https://firebasehybridaihackathon.devpost.com/','hybrid_ai',False,True,'Real Firebase AI Logic hybrid, public repo, demo, YouTube video; watch quota'),
    Hunt('gemma','Gemma 4 Developer Agent','2026-12-02T23:59:00Z','https://www.kaggle.com/competitions/gemma-4-developer-agent','code_agent',False,True,'Accept rules by Nov 25; actual supported Gemma model required'),
    Hunt('tenstorrent','Tenstorrent tt-metal #64647',None,'https://github.com/tenstorrent/tt-metal/issues/64647','sharded_mask',False,True,'NO AI/automation claiming. Existing competing PR #64731. Hardware validation required'),
)

def check_plan(slug: str, now: Optional[datetime] = None) -> dict:
    hunt = next((h for h in HUNTS if h.slug == slug),None)
    if hunt is None: raise KeyError(slug)
    now = now or datetime.now(timezone.utc)
    deadline = datetime.fromisoformat(hunt.deadline_utc.replace('Z','+00:00')) if hunt.deadline_utc else None
    return {'track':hunt.track,'name':hunt.name,'can_work_offline':True,
            'deadline_passed': bool(deadline and now >= deadline),
            'registration_verified':False,'submission_verified':False,'money_received':0,
            'cash_required_for_starter':hunt.cash_required,
            'blockers':hunt.restrictions,'register_url':hunt.register_url}
