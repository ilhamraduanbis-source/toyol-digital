"""Head-up-display brief composer with noninteractive, zero-cost simulation."""
from dataclasses import dataclass

MAX_LINE=30
MAX_LINES=4

def wrap_card(title: str, content: str) -> list[str]:
    tokens=(title.strip()+' — '+content.strip()).split()
    if not tokens: return ['No item']
    lines=[]; current=''
    for token in tokens:
        if len(token)>MAX_LINE: token=token[:MAX_LINE-1]+'…'
        if len(current)+(1 if current else 0)+len(token) > MAX_LINE:
            if current: lines.append(current)
            current=token
        else:
            current=(' '.join([current,token]) if current else token)
        if len(lines)==MAX_LINES: break
    if current and len(lines)<MAX_LINES:lines.append(current)
    if len(lines)==MAX_LINES and len(' '.join(tokens))>sum(len(x) for x in lines):
        lines[-1]=lines[-1][:MAX_LINE-1]+'…'
    return lines

@dataclass
class HUD:
    items:list[tuple[str,str]]
    index:int=0
    def __post_init__(self):
        if not self.items: raise ValueError('Need at least one card')
    def swipe(self,direction:str):
        if direction=='right' or direction=='down':self.index=(self.index+1)%len(self.items)
        elif direction=='left' or direction=='up':self.index=(self.index-1)%len(self.items)
        else:raise ValueError('Unknown gesture')
        return self.view()
    def view(self):
        a,b=self.items[self.index]
        return {'index':self.index+1,'total':len(self.items),'lines':wrap_card(a,b),'width':576,'height':288}
