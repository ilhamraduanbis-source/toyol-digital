"""Safe preliminary patch checking for Gemma contest: NOT a Gemma model, NOT a submission agent."""
import ast
from pathlib import Path
import re

class PatchRejected(ValueError):pass

def validate_python_patch(relative_path:str, source:str, *, max_bytes:int=120_000)->dict:
    if not relative_path or relative_path.startswith(('/', '\\')) or '..' in Path(relative_path).parts:
        raise PatchRejected('Path outside repository')
    if not relative_path.endswith('.py'):raise PatchRejected('Only Python sources supported')
    if len(source.encode())>max_bytes:raise PatchRejected('Too large')
    try:ast.parse(source,filename=relative_path)
    except SyntaxError as e:raise PatchRejected(f'Syntax error at line {e.lineno}') from e
    return {'path':relative_path,'syntax':'PASS','bytes':len(source.encode()),'task':'human_review_required'}

def detect_simple_off_by_one(code:str)->list[dict]:
    """Suggest review only; never auto-edit arbitrary code."""
    candidates=[]
    for n,line in enumerate(code.splitlines(),1):
        if re.search(r'\brange\(len\(\w+\)\s*\+\s*1\)',line):
            candidates.append({'line':n,'reason':'Potential out-of-range indexing; inspect loop body'})
    return candidates
