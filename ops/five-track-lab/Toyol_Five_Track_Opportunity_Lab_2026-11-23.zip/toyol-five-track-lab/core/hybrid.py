"""Zero-spend hybrid routing baseline for Firebase track. This is NOT the Firebase SDK."""
import re
from dataclasses import dataclass
from typing import Callable

class CloudNotPermitted(Exception):
    pass

@dataclass
class Response:
    text: str
    path: str
    redacted: bool

# Intentionally conservative. Do not transmit sensitive raw inputs to paid cloud APIs.
def redact(text: str) -> str:
    text = re.sub(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b','[EMAIL]',text,flags=re.I)
    text = re.sub(r'\b\+?\d{10,15}\b','[PHONE]',text)
    return text

class HybridRouter:
    def __init__(self, local: Callable[[str],str], cloud: Callable[[str],str]):
        self.local, self.cloud = local, cloud
        self.cloud_calls = 0
    def ask(self,prompt:str, *, allow_cloud=False, free_quota_confirmed=False, redact_cloud=True) -> Response:
        if not isinstance(prompt,str) or not prompt.strip(): raise ValueError('Prompt required')
        try:
            answer=self.local(prompt)
            if not answer: raise RuntimeError('Local model returned empty result')
            return Response(answer,'device',False)
        except Exception as error:
            if not allow_cloud or not free_quota_confirmed:
                raise CloudNotPermitted('No cloud request. Explicit consent AND verified free quota are required.') from error
            safe=redact(prompt) if redact_cloud else prompt
            if redact(prompt)!=prompt and not redact_cloud:
                raise CloudNotPermitted('Personal information cannot be sent unredacted')
            self.cloud_calls += 1
            return Response(self.cloud(safe),'cloud',safe!=prompt)
