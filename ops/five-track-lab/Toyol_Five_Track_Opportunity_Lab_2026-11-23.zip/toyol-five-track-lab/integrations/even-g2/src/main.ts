// Functional Even Hub SDK path, adapted from official 'minimal' template.
// Real SDK + simulator validation is required before hackathon submission.
import {
  waitForEvenAppBridge, TextContainerProperty, CreateStartUpPageContainer,
  TextContainerUpgrade, OsEventTypeList,
} from '@evenrealities/even_hub_sdk'

const cards = [
  'PROOFDESK 1/5\nBrowser QA\nAutomated UI tests\nVerified locally',
  'PROOFDESK 2/5\nEven G2\nTap to move\nDouble tap to exit',
  'PROOFDESK 3/5\nHybrid AI\nDevice first\nCloud blocked by default',
  'PROOFDESK 4/5\nGemma 4\nPatch checks\nRules acceptance required',
  'PROOFDESK 5/5\nKernel masks\nBatch & shard tests\nNo auto-bounty claims',
]
let index = 0
const bridge = await waitForEvenAppBridge()
const initial = new TextContainerProperty({
  xPosition:0,yPosition:0,width:576,height:288,
  borderWidth:0,borderColor:5,paddingLength:4,
  containerID:1,containerName:'proof',content:cards[0],isEventCapture:1,
})
const created = await bridge.createStartUpPageContainer(new CreateStartUpPageContainer({
  containerTotalNum:1,textObject:[initial],
}))
if (created !== 0) throw new Error('G2 page creation failed: '+created)

function getType(x?:{eventType?:OsEventTypeList}):OsEventTypeList|null {
  if (!x) return null
  return x.eventType ?? OsEventTypeList.CLICK_EVENT
}
const unsubscribe = bridge.onEvenHubEvent(event=>{
  const sys=getType(event.sysEvent)
  const text=getType(event.textEvent)
  if (sys===OsEventTypeList.DOUBLE_CLICK_EVENT || text===OsEventTypeList.DOUBLE_CLICK_EVENT){
    void bridge.shutDownPageContainer(1);return
  }
  if (sys===OsEventTypeList.CLICK_EVENT || text===OsEventTypeList.CLICK_EVENT){
    index=(index+1)%cards.length
    void bridge.textContainerUpgrade(new TextContainerUpgrade({
      containerID:1,containerName:'proof',content:cards[index],
    }))
    return
  }
  if (sys===OsEventTypeList.SYSTEM_EXIT_EVENT || sys===OsEventTypeList.ABNORMAL_EXIT_EVENT) unsubscribe()
})
