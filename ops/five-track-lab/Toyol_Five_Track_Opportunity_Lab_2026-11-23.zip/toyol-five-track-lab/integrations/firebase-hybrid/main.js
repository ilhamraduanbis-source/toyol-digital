// Real Firebase AI Logic Web SDK integration; never contact cloud by default.
// Requires a registered Firebase app, optional App Check, and supported Chrome desktop.
import { initializeApp } from 'firebase/app'
import { getAI, getGenerativeModel, GoogleAIBackend, InferenceMode } from 'firebase/ai'

const app = initializeApp({
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
})
const ai = getAI(app, { backend: new GoogleAIBackend() })
// Cloud fallback requires both a deliberate opt-in and confirmation that this
// exact project has no spend path enabled. Without both, ONLY_ON_DEVICE is used.
const allowCloud = import.meta.env.VITE_ALLOW_CLOUD === 'true' &&
  import.meta.env.VITE_FREE_QUOTA_VERIFIED === 'true'
const model = getGenerativeModel(ai, {
  mode: allowCloud ? InferenceMode.PREFER_ON_DEVICE : InferenceMode.ONLY_ON_DEVICE,
})
const output=document.querySelector('#output')
document.querySelector('#start').addEventListener('click', async ()=>{
  const input=document.querySelector('#input').value.trim()
  if (!input){output.textContent='Provide a prompt';return}
  output.textContent='Preparing on-device model…'
  try {
    // Must happen after user interaction. This can download the local model.
    await model.initializeDeviceModel(p=>{output.textContent=`On-device progress ${Math.round(p*100)}%`})
    const res=await model.generateContent(input)
    output.textContent=res.response.text()
  } catch(e){output.textContent='No paid fallback performed. '+String(e)}
})
