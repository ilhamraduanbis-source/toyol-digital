# Competition integration gates — never infer registration from a build

All modules have a ZERO-spend default. These are source preparations, not contest entries.

## KaneCLI, due 26 Nov 2026 23:59 IST

- Official registration: https://www.kaneclihack.sh/o/register
- Register with TestMu AI and claim stated promotional credits if truly free and no payment method required.
- Build ProofDesk UI in `web/`; run `python tests/browser_e2e.py` (real local Playwright).
- Remaining: use **Kane CLI itself**, save its authentic run output, review organizer scoring, and submit genuine video and links via official form.
- Never label Playwright execution as Kane CLI execution.

## Even Realities, closes 29 Nov 2026 19:59 UTC

- Event: https://aihackathon.app/e/even-realities-heads-up-2026/
- SDK source in `integrations/even-g2/`, built using official `waitForEvenAppBridge` pattern.
- Set up free simulator: `npm install && npm run dev` then `npm run sim`.
- Remaining: actual simulator/SDK validation, public repo demo, <=3 minute video, sign-in and organizer submission.

## Firebase, closes 30 Nov 2026 22:00 UTC

- Event: https://firebasehybridaihackathon.devpost.com/
- Actual Firebase AI Logic import and `initializeDeviceModel` in `integrations/firebase-hybrid`.
- Configure a real Firebase project locally. Verify no billing/card requirements and quota.
- Default ONLY_ON_DEVICE avoids accidental cloud fallback; switching to PREFER_ON_DEVICE is guarded by explicit variables.
- Remaining: real SDK run on compatible Chrome desktop, hosted test demo, public repository, YouTube video, Devpost sign-in and submission.

## Gemma 4, accept rules no later than 25 Nov 2026, final 2 Dec 2026

- Official: https://www.kaggle.com/competitions/gemma-4-developer-agent
- Capability: `core/gemma_guard.py` prevents path traversal and syntax errors; includes basic diagnostic patterns.
- Remaining: personal Kaggle rules acceptance; run an actual supported Gemma 4 model in Kaggle notebook; genuine `agent.yaml` + submission bundle and benchmark. This repo DOES NOT supply a competition-ready model.
- Separate optional paper track is already past its 12 Nov deadline; do not attempt.

## Tenstorrent #64647, contested bounty

- Official: https://github.com/tenstorrent/tt-metal/issues/64647
- Existing PR: https://github.com/tenstorrent/tt-metal/pull/64731
- Capability: `core/tenstorrent_mask.py` has shape, mask layout, orientation, wrap and batch tests.
- STRICT policy: do not make an AI-generated/automatic claim, comment, or assignment request. Human-owned/manual interactions only. Requires hardware CI/codeowner review to validate an upstream PR.

## Security and financial policy

Do not: deposit, run paid metered services, enter payment info, submit untested entries, claim a bounty via AI, store credentials, publish personal information, fake screenshots or model benchmark results.
