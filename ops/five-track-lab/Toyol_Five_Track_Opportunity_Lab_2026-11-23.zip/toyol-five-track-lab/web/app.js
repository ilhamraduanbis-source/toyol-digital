// Offline demonstrator. No network calls, no false registration or payment statuses.
const hunts = [
 {slug:'kane',name:'KaneCLI',description:'Automated browser QA and reproducible UI evidence.',deadline:'26 Nov · 23:59 IST',url:'https://www.kaneclihack.sh/o/register'},
 {slug:'even',name:'Even Realities',description:'576×288 glanceable cards, navigation, and event-adapter prototype.',deadline:'29 Nov · 19:59 UTC',url:'https://www.eventbrite.com/e/heads-up-even-realities-hackathon-by-tvm-ventures-daos-hub-tickets-2004953173915'},
 {slug:'firebase',name:'Firebase Hybrid AI',description:'Device-first inference and guarded fallback. SDK integration still required.',deadline:'30 Nov · 14:00 PST',url:'https://firebasehybridaihackathon.devpost.com/'},
 {slug:'gemma',name:'Gemma 4 Agent',description:'Syntax patch guards, diagnostic review and deterministic test fixtures.',deadline:'Accept rules 25 Nov',url:'https://www.kaggle.com/competitions/gemma-4-developer-agent'},
 {slug:'tenstorrent',name:'Tenstorrent',description:'Mask layout, batch boundary and shard orientation test skills. No AI bounty claims.',deadline:'Bounty contested',url:'https://github.com/tenstorrent/tt-metal/issues/64647'}
];
const $ = id=>document.getElementById(id);
function escapeHtml(s){return s.replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));}
let active='all',hudIndex=0;
function render(){const items=hunts.filter(h=>active==='all'||h.slug===active);
 $('count').textContent=items.length;
 $('section-title').textContent=active==='all'?'Opportunity registry':items[0].name;
 $('cards').innerHTML=items.map(h=>`<article class="item" data-slug="${h.slug}"><div class="item-head"><h3>${escapeHtml(h.name)}</h3><span class="tag">Not enrolled</span></div><p>${escapeHtml(h.description)}</p><div class="meta">${escapeHtml(h.deadline)}</div><p><a rel="noopener" target="_blank" href="${h.url}">Official entry details</a></p></article>`).join('');
 hudIndex=0;renderHud();}
function wrap(text,max=30,lines=4){const tokens=text.split(/\s+/);let rows=[],current='';for(const token of tokens){const word=token.length>max?token.slice(0,max-1)+'…':token;if((current+' '+word).trim().length>max){if(current)rows.push(current);current=word;}else current=(current+' '+word).trim();if(rows.length===lines)break;}if(current&&rows.length<lines)rows.push(current);if(rows.length===lines&&text.length>rows.join(' ').length)rows[lines-1]=rows[lines-1].slice(0,max-1)+'…';return rows;}
function renderHud(){const items=hunts.filter(h=>active==='all'||h.slug===active);hudIndex=((hudIndex%items.length)+items.length)%items.length;const h=items[hudIndex];$('hud-lines').textContent=wrap(`${h.name}: ${h.description}`,29).join('\n');$('hud-progress').textContent=`${hudIndex+1}/${items.length} · SIMULATION`;}
for(const b of document.querySelectorAll('[data-track]'))b.addEventListener('click',()=>{active=b.dataset.track;for(const x of document.querySelectorAll('[data-track]')){const chosen=x===b;x.classList.toggle('active',chosen);x.setAttribute('aria-pressed',String(chosen));}render();});
$('prev').addEventListener('click',()=>{hudIndex--;renderHud();});$('next').addEventListener('click',()=>{hudIndex++;renderHud();});
$('run').addEventListener('click',()=>{const p=$('prompt').value.trim();if(!p){$('route-result').textContent='Error: prompt required';return;}const cloud=$('cloud').checked;$('route-result').textContent=cloud?'Device-first demo. Cloud NOT called; this lab has no configured Firebase account or verified free quota.':'Device-first demo only. Cloud blocked, zero external calls.';});
$('export').addEventListener('click',()=>{const doc={generated_at:new Date().toISOString(),tracks:hunts.map(x=>({slug:x.slug,registration_verified:false,submission_verified:false,paid_usd:0})),warning:'Local demonstration; no registrations or awards verified'};const blob=new Blob([JSON.stringify(doc,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const anchor=document.createElement('a');anchor.href=url;anchor.download='toyol-hunt-status.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),500);});
render();
